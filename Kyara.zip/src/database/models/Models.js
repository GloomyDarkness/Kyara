module.exports = {
    guilds: require('./Guild'),
    users: require("./User")
}